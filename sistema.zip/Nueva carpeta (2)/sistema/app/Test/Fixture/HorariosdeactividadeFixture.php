<?php
/**
 * HorariosdeactividadeFixture
 *
 */
class HorariosdeactividadeFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'Actividad' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 40, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'Hora' => array('type' => 'time', 'null' => false, 'default' => null),
		'Instructor' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 50, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'Dias' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 30, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'Modified' => array('type' => 'datetime', 'null' => true, 'default' => null),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => null),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'Actividad' => 'Lorem ipsum dolor sit amet',
			'Hora' => '22:23:58',
			'Instructor' => 'Lorem ipsum dolor sit amet',
			'Dias' => 'Lorem ipsum dolor sit amet',
			'Modified' => '2015-04-17 22:23:58',
			'created' => '2015-04-17 22:23:58'
		),
	);

}

<?php
App::uses('AppModel', 'Model');
/**
 * Basquetbol Model
 *
 */
class Basquetbol extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'No_Control';

}

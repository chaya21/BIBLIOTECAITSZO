<?php
class ProductsController extends AppController {
	
	public function logout() {

	}
	public function index() {

	}

}